myConst {
	template {
		dir  = typo3conf/ext/ktempl/
	}
}


styles.content.imgtext.maxW = 2000
styles.content.imgtext.maxWInText = 2000
styles.content.imgtext.maxH = 2000
styles.content.imgtext.maxHInText = 2000
